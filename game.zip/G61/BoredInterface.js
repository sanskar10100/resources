console.log("BoredInterface.js");
var BoredInterface =  new function() {
	var VERSION = 2;
	this.getVersion = function(){return VERSION;}

	var bridge = {};
	var storage = {};
	var logger = function(s){return console.log(s)};

	this.setBridge = function(brd){
		bridge = brd;
	}

	this.setStorage = function(str){
		storage = str;
	}

	this.setLogger = function(lgr){
		logger = lgr;
	}

	//Storage related

	this.isStorageSystemAvailable = function(){//returns boolean
		if (bridge.isStorageSystemAvailable){
			return bridge.isStorageSystemAvailable();
		}
		return false;
	}

	//both key and value has to be string and non-null
	//if an object is to be saved, first stringify then call this function
	this.saveStringForKey = function(key, value){
		if (typeof value != "string"){
			logger("saveStringForKey -> can only save string", true);
			return;
		}
		if (typeof key != "string"){
			logger("saveStringForKey -> key should be string", true);
			return;
		}
		if (!this.isStorageSystemAvailable()){
			logger("storage system is not available, called saveStringForKey", true);
			return;
		}

		storage[key] = value;
		bridge.saveStringForKey(key, value);
		logger("savedString: key = "+key+", value = "+value);
	}

	//value for the specified key is removed
	this.removeStringForKey = function(key){
		if (typeof key != "string"){
			logger("removeStringForKey -> key should be string", true);
			return;
		}
		if (!this.isStorageSystemAvailable()){
			logger("storage system is not available, called removeStringForKey", true);
			return;
		}
		delete storage[key];
		bridge.removeStringForKey(key);
		logger("removed key "+key);
	}

	this.keyExists = function(key){
		if (!this.isStorageSystemAvailable){
			return false;
		}
		if (storage[key]){
			return true;
		}
		return false;
	}

	//returns null if doesn't exist
	this.getStringForKey = function(key){
		if (typeof key != "string"){
			logger("getStringForKey -> key should be string", true);
			return;
		}
		if (!this.isStorageSystemAvailable()){
			logger("storage system is not available, called getStringForKey", true);
			return;
		}
		var value = storage[key];
		logger("getString: key = "+key+", value = "+value);
		return value;
	}


	//Purchase Related

	//check if can show rewarded video
	this.isRewardedAvailable = function(){ //returns true or false
		if (bridge.isRewardedAvailable){
			return bridge.isRewardedAvailable();
		}
		return false;
	};

	var rewardedListener;
	//listener is a function that takes boolean as a parameter. 
	//called everytime when rewarded availability is changed. only one listener is allowed at once. 
	//to remove listener call this function with null value.
	//listener will be called immediately once with the current state
	this.setRewardedListener = function(listener){ 
		logger("rewarded listener set");
		rewardedListener = listener;
		listener(this.isRewardedAvailable());
	};

	//to be called by app
	this.rewardedAvailabilityChanged = function(availability){
		if (rewardedListener){
			rewardedListener(availability);
		}
	}

	this.isCoinSystemAvailable = function(){ //returns true or false
		if (bridge.isCoinSystemAvailable){
			return bridge.isCoinSystemAvailable();
		}
		return false;
	}

	this.getNumberOfCoins = function(){ //returns number
		if (bridge.getNumberOfCoins){
			return bridge.getNumberOfCoins();
		}
		return 0;
	}

	//returns image object
	this.getCoinImage = function(){
		if (bridge.getCoinImage){
			return bridge.getCoinImage();
		}
		return new Image();
	}


	var coinListener;
	//listener is a function that takes number of coins as a parameter. 
	//called everytime when number of coins is changed. only one listener is allowed at once. 
	//to remove listener call this function with null value.
	//listener will be called immediately once with the current value
	this.setCoinListener = function(listener){
		logger("coin listener set");
		coinListener = listener;
		listener(this.getNumberOfCoins());
	}

	//to be called from app
	this.coinCountChanged = function(count){
		if (coinListener){
			coinListener(count);
		}
	}

	//callback is a function that takes boolean as argument. called with true if one more chance is granted
	//Code is string and is not optional. Should not contain special characters including space
	//requiredCoins is an optional number. if it is null rewarded video will be showed
	//if requiredCoins is not null, and if coin balance is sufficient, coins will be deducted from the balance
	//title is the name of the purchase and is optional
	this.requestOneMoreChance = function(code, callback, requiredCoins, title){
		logger("requestOneMoreChance");
		if (bridge.requestOneMoreChance){
			bridge.requestOneMoreChance(code, callback, requiredCoins, title);
		}else{
			callback(false);
		}
	}

	//callback is a function that takes boolean as argument. called with true if power up is granted
	//Code is string and is not optional. Should not contain special characters including space
	//requiredCoins is an optional number. if it is null rewarded video will be showed
	//if requiredCoins is not null, and if coin balance is sufficient, coins will be deducted from the balance
	//title is the name of the purchase and is optional
	this.requestPowerUp = function(code, callback, requiredCoins, title){
		logger("requestPowerUp");
		if (bridge.requestPowerUp){
			bridge.requestPowerUp(code, callback, requiredCoins, title);
		}else{
			callback(false);
		}
	}


	//generic purchase function for purchases that doesn't fall into one more chance or power up categories
	//Code is string and is not optional. Should not contain special characters including space
	//callback is a function that takes boolean as argument. called with true if power up is granted
	//requiredCoins is an optional number. if it is null rewarded video will be showed
	//if requiredCoins is not null, and if coin balance is sufficient, coins will be deducted from the balance
	//title is the name of the purchase and is optional
	this.requestPurchase = function(code, callback, requiredCoins, title){
		logger("requestPurchase");
		if (bridge.requestPurchase){
			bridge.requestPurchase(code, callback, requiredCoins, title);
		}else{
			callback(false);
		}
	}


// Code is string and is not optional. Should not contain special characters including space.
// Callback is a function that takes a number as argument[function(gainedTokens)]. called with number of tokens if the exchange is confirmed, otherwise called with 0. User may have an option to buy more tokens than initially requested.
// requiredCoins is a number and is not optional
// requestedTokens is a number and is not optional
// Token is in-game currency and coin is an in-app currency. Game requests tokens in exchange of coins
// tokenName is a string and is not optional. It is singular
// tokenImage is an Image object and is optional
	this.requestExchange = function(code, callback, requiredCoins, requestedTokens, tokenName, tokenImage){
		logger("requestExchange");
		if (bridge.requestExchange){
			bridge.requestExchange(code, callback, requiredCoins, requestedTokens, tokenName, tokenImage);
		}else{
			callback(false);
		}
	}



	//Events

	//to be called when all loading is done and game is ready to be played
	this.gameLoaded = function(){
		logger("game loaded");
		if (bridge.gameLoaded){
			bridge.gameLoaded();
		}
	}

	//TODO round progress
	this.loadProgressChanged = function(progress){//progress is an integer between 0-100
		logger("load progress "+progress);
		if (bridge.loadProgressChanged){
			bridge.loadProgressChanged(Math.floor(progress));
		}
	}

	//to be called when each level starts
	this.levelStarted = function(levelNum){
		logger("level started "+levelNum);
		if (bridge.levelStarted){
			bridge.levelStarted(levelNum);
		}
	}

	//to be called when level ends
	this.levelEnded = function(levelNum, didPass){//didPass is boolean indicating if the level was successfull
		logger("level ended, level "+levelNum+" did pass "+didPass);
		if (bridge.levelEnded){
			bridge.levelEnded(levelNum, didPass);
		}
	}

	//to be called when non-level games start
	this.gameStarted = function(){
		logger("game started");
		if (bridge.gameStarted){
			bridge.gameStarted();
		}
	}

	//to be called when non-level games end
	this.gameEnded = function(score){//score is optional since some games don't have it
		logger("game ended, score: "+score);
		if (bridge.gameEnded){
			bridge.gameEnded(score);
		}
	}


	//score is not optional
	//every game will select which score to use in the leaderboard
	//if there is only one score (for example in a non-level game) both gameEnded function and leaderboardScore 
	//function will be called 
	//every game that will have a leaderboard has to call this function
	this.leaderboardScore = function(score){
		logger("leaderboardScore: "+score);
		if (bridge.leaderboardScore){
			bridge.leaderboardScore(score);
		}
	}


	this.logEvent = function(key, dict){//key is string dict is object {string:string}
		logger("logEvent: key = "+key+", dict: "+JSON.stringify(dict));
		if (bridge.logEvent){
			bridge.logEvent(key, dict);
		}
	}

	//this function should be called if user buys these options with in-game currency rather that with coin system or ads
	this.didUseOneMoreChance = function(code){//code should not contain any special characters including space
		logger("didUseOneMoreChance "+code);
		if (bridge.didUseOneMoreChance){
			bridge.didUseOneMoreChance(code);
		}
	}

	//this function should be called if user buys these options with in-game currency rather that with coin system or ads
	this.didUsePowerUp = function(code){//code should not contain any special characters including space
		logger("didUsePowerUp "+code);
		if (bridge.didUsePowerUp){
			bridge.didUsePowerUp(code);
		}
	}

	//this function should be called if user buys these options with in-game currency rather that with coin system or ads
	this.didCompletePurchase = function(code){//code should not contain any special characters including space
		logger("didCompletePurchase "+code);
		if (bridge.didCompletePurchase){
			bridge.didCompletePurchase(code);
		}
	}

	//To be called when it’s appropriate to show full screen ad
	this.canShowAd = function(){
		logger("can show ad");
		if (bridge.canShowAd){
			bridge.canShowAd();
		}
		window.dispatchEvent(new CustomEvent('BoredButtonGameOver'));
	}


	//Other


	//each game that has sound should call this function on load and act accordingly
	this.getVolume = function(){ //returns the volume
		if (bridge.getVolume){
			return bridge.getVolume();
		}
		return 1;
	}


	var volumeListener;
	//listener is a function that takes number as a parameter. 
	//called everytime when volume is changed. only one listener is allowed at once. 
	//to remove listener call this function with null value.
	//listener will be called immediately once with the current volume
	this.setVolumeListener = function(listener){
		logger("volume listener set");
		volumeListener = listener;
		listener(this.getVolume());
	}

	//to be called from app
	this.volumeChanged = function(volume){
		if (volumeListener){
			logger("volme changed "+volume);
			volumeListener(volume);
		}
	}


	var pauseListener;
	//listener is a function that takes boolean as a parameter. 
	//only one listener is allowed at once. 
	//to remove listener call this function with null value.
	//called with true is game should pause, called with false if game should resume
	this.setPauseListener = function(listener){
		logger("pause listener set");
		pauseListener = listener;
	}

	this.pauseStateChanged = function(isPaused){
		logger("pause state changed: isPaused = "+isPaused);
		if (pauseListener){
			pauseListener(isPaused);
		}
	}


	//games can request notifications to be sent at a future date
	//requesting a notification doesn't guarantee to be sent
	this.requestNotification = function(epochTimeSecs, text){

	}

	//deletes all previously requested notifications
	this.clearRequestedNotifications = function(){

	}



};









